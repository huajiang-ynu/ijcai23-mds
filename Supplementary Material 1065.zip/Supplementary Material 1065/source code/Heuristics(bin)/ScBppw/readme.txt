usage:


./ScBppw instance 10 1
(The instance is a file in DIMACS graph format. )
10 is the cutoff time (s)
1 is the seed

for example:

./ScBppw ./bio-celegans 10 1