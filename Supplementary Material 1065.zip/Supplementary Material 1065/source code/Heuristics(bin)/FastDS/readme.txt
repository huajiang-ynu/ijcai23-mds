usage:

./fastds instance 1 10 60

(The instance is a file in DIMACS graph format. )
1 is the seed
10 is the cutoff time (s)
60 is a fixed parameter

for example:

./fastds ./bio-celegans 1 10 60