# Provided in this supplementary material are the following three directories:

## datasets

Experiments were conducted on the following three datasets, which are offered in this directory:

+ UDG: 120 instances are provided in this dataset.

+ T1: 530 instances are provided in this dataset.

+ Real-world graphs: Limited by memory space, please refer to  Network Repository (http://networkrepository.com/networks.php) to download the instances, if necessary.

  

## source code

The code of EMOS, the algorithm proposed in this paper, is available in this directory.

 The source code of the three heuristic algorithms was kindly provided by their authors and was compiled using GNU g++ -O3 under Linux.  Since they are not open source, here we only present their bin files. 

For more details on usage, please refer to *README*  in each subfolder.



## experimental results

In this directory, we present detailed computational results recorded in our experiments. 
